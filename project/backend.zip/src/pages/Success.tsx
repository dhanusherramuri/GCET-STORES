// import React from 'react';

const Success = ()=>{
    return(<h1>SUCCESSFULLY SUBMITTED REQUEST</h1>);
};

export default Success;